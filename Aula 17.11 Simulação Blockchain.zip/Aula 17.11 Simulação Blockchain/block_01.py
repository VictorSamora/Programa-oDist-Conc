import hashlib
import json

class Block:
    def __init__(self, index, timestamp, data, prior_hash=''):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.prior_hash = prior_hash
        self.hash = self.create_hash()

    def create_hash(self):
        blockstring = f"{self.index}{self.prior_hash}{self.timestamp}{self.data}".encode()
        return hashlib.sha256(blockstring).hexdigest()

class StudentBlockChain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]

    def create_genesis_block(self):
        return Block(0, '17/11/2025', "MyFirstBlockChainUVV.br",'0')     

    def get_last_block(self):
        return self.chain[-1] 
    
    def add_block(self, new_block):
        new_block.prior_hash = self.get_last_block().hash
        new_block.hash = new_block.create_hash()
        self.chain.append(new_block)
    
    def validating_blockchain(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previuos_block = self.chain[i-1]

            if current_block.hash != current_block.create_hash():
                return False
            if current_block.prior_hash != previuos_block.hash:
                return False
        
        return True

if __name__ == '__main__':
    student_coin = StudentBlockChain()
    firstblock = student_coin.create_genesis_block()

    student_coin.add_block(Block(1, '12/11/2025', 'amount = 27'))
    student_coin.add_block(Block(2, '15/11/2025', 'amount = 13'))
    student_coin.add_block(Block(3, '21/11/2025', 'amount = 73'))


    #print(firstblock)
    #print(json.dumps(student_coin.chain, default=lambda o: o.__dict__, indent=4))
    #print(student_coin.get_last_block().hash)

    print('Is student_coins valid?' + str(student_coin.validating_blockchain()))

    student_coin.chain[1].data = 'amount = 28'

    print('Is student_coins valid after change?' + str(student_coin.validating_blockchain()))

    student_coin.chain[1].hash = student_coin.chain[1].create_hash()
    print('Is student_coins valid after updating hash?' + str(student_coin.validating_blockchain()))
    print('Is student_coins valid?' + str(student_coin.validating_blockchain()))
    print(json.dumps(student_coin.chain, default=lambda o: o.__dict__, indent=4))