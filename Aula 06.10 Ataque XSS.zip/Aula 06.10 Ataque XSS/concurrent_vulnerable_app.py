from flask import Flask, request, render_template_string
import threading
import time

app = Flask(__name__)

# Estado compartilhado
counter = 0             # contador para demonstrar lost updates
entries = []            # lista que armazena entradas (stored XSS demo)

# Option: use lock to protect state; comece com use_lock = False para ver a corrida
use_lock = True
state_lock = threading.Lock()

INDEX_HTML = """
<!doctype html>
<html>
  <head><meta charset="utf-8"><title>Concorrência + XSS (demo)</title></head>
  <body>
    <h1>Concorrência + XSS (APENAS LOCAL)</h1>

    <h2>Formulário (stored entry)</h2>
    <form action="/submit" method="post">
      <input name="q" size="60" placeholder="Cole o payload aqui" />
      <button type="submit">Enviar</button>
    </form>

    <h2>Contador (increment)</h2>
    <form action="/increment" method="post">
      <button type="submit">Incrementar 1</button>
    </form>
    <p>Valor do contador: <strong>{{ counter }}</strong></p>

    <hr/>
    <h3>Entries (mostrar sem escapar) — stored XSS demo</h3>
    <ul>
    {% for e in entries %}
      <li>{{ e|safe }}</li>
    {% endfor %}
    </ul>

    <hr/>
    <p><small>use_lock = {{ use_lock }}</small></p>
  </body>
</html>
"""

@app.route("/", methods=["GET"])
def index():
    # mostra estado atual
    return render_template_string(INDEX_HTML,
                                  counter=counter,
                                  entries=entries,
                                  use_lock=use_lock)

@app.route("/submit", methods=["POST"])
def submit():
    global entries
    q = request.form.get("q", "")
    # Intencionalmente não escapamos → stored XSS
    if use_lock:
        with state_lock:
            entries.append(q)
    else:
        # sem lock: possível corrida se múltiplas threads adicionarem ao mesmo tempo
        entries.append(q)
    return ("", 302, {"Location": "/"})

@app.route("/increment", methods=["POST"])
def increment():
    global counter
    # Simular alguma operação que leva tempo para aumentar chance de race
    if use_lock:
        with state_lock:
            tmp = counter
            time.sleep(0.001)   # força um pequeno atraso para aumentar probabilidade de colisão
            tmp += 1
            counter = tmp
    else:
        tmp = counter
        time.sleep(0.001)
        tmp += 1
        counter = tmp
    return ("", 302, {"Location": "/"})

@app.route("/reset", methods=["POST"])
def reset():
    global counter, entries
    if use_lock:
        with state_lock:
            counter = 0
            entries = []
    else:
        counter = 0
        entries = []
    return ("", 302, {"Location": "/"})

if __name__ == "__main__":
    # rodar multithreaded para aceitar requisições concorrentes
    app.run(host="127.0.0.1", port=5000, debug=True, threaded=True)
