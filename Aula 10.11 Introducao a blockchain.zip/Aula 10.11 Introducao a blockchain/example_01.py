My_string = "Ola mundo!"

hash_value1 = hash(My_string)
hash_value2 = hash(My_string)


print("String:", My_string)
print("Value Hash 1:", hash_value1)
print("Value Hash 2:", hash_value2)

print(hash_value1 == hash_value2)
